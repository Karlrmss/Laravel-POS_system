@extends('layouts.app')

@section('title', 'Customers')
@section('heading', 'Customers')

@section('content')
    <div class="panel">
        <div class="panel-heading">
            <div><p class="eyebrow">Directory</p><h2>Customer records</h2><p>Keep contact information accurate and up to date.</p></div>
            <a class="button primary" href="{{ route('customers.create') }}">＋ Add customer</a>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>Customer</th><th>Phone</th><th>Address</th><th class="align-right">Action</th></tr></thead>
                <tbody>
                @forelse ($customers as $customer)
                    <tr>
                        <td><div class="identity"><span class="initials">{{ str($customer->full_name)->substr(0, 1)->upper() }}</span><div><strong>{{ $customer->full_name }}</strong><small>{{ $customer->email }}</small></div></div></td>
                        <td>{{ $customer->phone ?: '—' }}</td>
                        <td>{{ $customer->address ?: '—' }}</td>
                        <td class="align-right"><a class="button ghost" href="{{ route('customers.edit', $customer) }}">Edit</a></td>
                    </tr>
                @empty
                    <tr><td colspan="4"><div class="empty-state"><strong>No customers yet</strong><span>Add the first customer to get started.</span></div></td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        @if ($customers->hasPages())
            <div class="pager">
                @if ($customers->onFirstPage()) <span>← Previous</span> @else <a href="{{ $customers->previousPageUrl() }}">← Previous</a> @endif
                <small>Page {{ $customers->currentPage() }} of {{ $customers->lastPage() }}</small>
                @if ($customers->hasMorePages()) <a href="{{ $customers->nextPageUrl() }}">Next →</a> @else <span>Next →</span> @endif
            </div>
        @endif
    </div>
@endsection
