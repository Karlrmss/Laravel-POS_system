@extends('layouts.app')

@section('title', 'Edit Customer')
@section('heading', 'Edit customer')

@section('content')
    <div class="form-page">
        <div class="form-intro"><a href="{{ route('customers.index') }}">← Back to customers</a><h2>Update customer details</h2><p>Editing {{ $customer->full_name }}.</p></div>
        <form class="panel form-panel" method="POST" action="{{ route('customers.update', $customer) }}" novalidate>
            @csrf
            @method('PUT')
            @include('customers._form')
        </form>
    </div>
@endsection
