@extends('layouts.app')

@section('title', 'Create Customer')
@section('heading', 'Create customer')

@section('content')
    <div class="form-page">
        <div class="form-intro"><a href="{{ route('customers.index') }}">← Back to customers</a><h2>New customer details</h2><p>Fields marked with an asterisk are required.</p></div>
        <form class="panel form-panel" method="POST" action="{{ route('customers.store') }}" novalidate>
            @csrf
            @include('customers._form')
        </form>
    </div>
@endsection
