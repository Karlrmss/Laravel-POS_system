@php($editing = isset($customer))

<div class="form-grid">
    <div class="field full">
        <label for="full_name">Full name <span>*</span></label>
        <input id="full_name" name="full_name" type="text" value="{{ old('full_name', $customer->full_name ?? '') }}" class="@error('full_name') invalid @enderror" autocomplete="name" required autofocus>
        @error('full_name') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field full">
        <label for="email">Email address <span>*</span></label>
        <input id="email" name="email" type="email" value="{{ old('email', $customer->email ?? '') }}" class="@error('email') invalid @enderror" autocomplete="email" required>
        @error('email') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field full">
        <label for="phone">Phone number <small>Optional</small></label>
        <input id="phone" name="phone" type="text" value="{{ old('phone', $customer->phone ?? '') }}" class="@error('phone') invalid @enderror" autocomplete="tel">
        @error('phone') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field full">
        <label for="address">Address <small>Optional</small></label>
        <textarea id="address" name="address" rows="3" class="@error('address') invalid @enderror">{{ old('address', $customer->address ?? '') }}</textarea>
        @error('address') <p class="field-error">{{ $message }}</p> @enderror
    </div>
</div>

<div class="form-actions">
    <a class="button secondary" href="{{ route('customers.index') }}">Cancel</a>
    <button class="button primary" type="submit">{{ $editing ? 'Save changes' : 'Create customer' }}</button>
</div>
