@extends('layouts.app')

@section('title', 'Dashboard')
@section('heading', 'Dashboard')

@section('content')
    <div class="hero-panel">
        <div>
            <span class="badge">TFA Laravel Activity</span>
            <h2>Welcome back, Karl.</h2>
            <p>Manage customer records and staff accounts from one clean workspace.</p>
        </div>
        <div class="hero-monogram" aria-hidden="true">POS</div>
    </div>

    <div class="stat-grid">
        <article class="stat-card">
            <span class="stat-icon blue">◎</span>
            <div><p>Total customers</p><strong>{{ number_format($customerCount) }}</strong></div>
            <a href="{{ route('customers.index') }}">View customers →</a>
        </article>
        <article class="stat-card">
            <span class="stat-icon violet">◇</span>
            <div><p>User accounts</p><strong>{{ number_format($userCount) }}</strong></div>
            <a href="{{ route('users.index') }}">View users →</a>
        </article>
    </div>

    <div class="panel quick-actions">
        <div class="panel-heading"><div><p class="eyebrow">Shortcuts</p><h2>Quick actions</h2></div></div>
        <div class="action-grid">
            <a href="{{ route('customers.create') }}"><span>＋</span><div><strong>Add customer</strong><small>Create a customer profile</small></div></a>
            <a href="{{ route('users.create') }}"><span>＋</span><div><strong>Add user account</strong><small>Register a staff member</small></div></a>
        </div>
    </div>
@endsection
