@php($editing = isset($user))

@if ($editing)
    <div class="upload-section">
        <img class="avatar avatar-large" src="{{ $user->avatar ? Storage::disk('public')->url($user->avatar) : asset('images/avatar-placeholder.svg') }}" alt="Current profile picture">
        <div class="field upload-field">
            <label for="avatar">Profile picture <small>Optional</small></label>
            <input id="avatar" name="avatar" type="file" accept="image/jpeg,image/png,image/webp" class="@error('avatar') invalid @enderror">
            <p class="field-help">JPG, PNG, or WebP · maximum 2 MB · cropped to 320 × 320 px</p>
            @error('avatar') <p class="field-error">{{ $message }}</p> @enderror
        </div>
    </div>
@endif

<div class="form-grid two-column">
    <div class="field">
        <label for="username">Username <span>*</span></label>
        <input id="username" name="username" type="text" value="{{ old('username', $user->username ?? '') }}" class="@error('username') invalid @enderror" autocomplete="username" required autofocus>
        <p class="field-help">Letters, numbers, dashes, and underscores only.</p>
        @error('username') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
        <label for="full_name">Full name <span>*</span></label>
        <input id="full_name" name="full_name" type="text" value="{{ old('full_name', $user->full_name ?? '') }}" class="@error('full_name') invalid @enderror" autocomplete="name" required>
        @error('full_name') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field full">
        <label for="email">Email address <small>Optional</small></label>
        <input id="email" name="email" type="email" value="{{ old('email', $user->email ?? '') }}" class="@error('email') invalid @enderror" autocomplete="email">
        @error('email') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
        <label for="password">Password <small>{{ $editing ? 'Leave blank to keep current' : 'Optional' }}</small></label>
        <input id="password" name="password" type="password" class="@error('password') invalid @enderror" autocomplete="new-password">
        @error('password') <p class="field-error">{{ $message }}</p> @enderror
    </div>
    <div class="field">
        <label for="password_confirmation">Confirm password</label>
        <input id="password_confirmation" name="password_confirmation" type="password" autocomplete="new-password">
    </div>
</div>

<div class="form-actions">
    <a class="button secondary" href="{{ route('users.index') }}">Cancel</a>
    <button class="button primary" type="submit">{{ $editing ? 'Save changes' : 'Create user' }}</button>
</div>
