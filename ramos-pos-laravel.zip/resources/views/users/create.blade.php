@extends('layouts.app')

@section('title', 'Create User')
@section('heading', 'Create user account')

@section('content')
    <div class="form-page wide">
        <div class="form-intro"><a href="{{ route('users.index') }}">← Back to user accounts</a><h2>New account details</h2><p>Set the staff member’s identity and optional login details.</p></div>
        <form class="panel form-panel" method="POST" action="{{ route('users.store') }}" novalidate>
            @csrf
            @include('users._form')
        </form>
    </div>
@endsection
