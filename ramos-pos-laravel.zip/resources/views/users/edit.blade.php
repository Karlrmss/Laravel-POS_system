@extends('layouts.app')

@section('title', 'Edit User')
@section('heading', 'Edit user account')

@section('content')
    <div class="form-page wide">
        <div class="form-intro"><a href="{{ route('users.index') }}">← Back to user accounts</a><h2>Update account</h2><p>Editing {{ $user->full_name }}.</p></div>
        <form class="panel form-panel" method="POST" action="{{ route('users.update', $user) }}" enctype="multipart/form-data" novalidate>
            @csrf
            @method('PUT')
            @include('users._form')
        </form>
    </div>
@endsection
