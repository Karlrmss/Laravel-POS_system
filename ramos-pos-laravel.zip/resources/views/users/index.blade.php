@extends('layouts.app')

@section('title', 'User Accounts')
@section('heading', 'User accounts')

@section('content')
    <div class="panel">
        <div class="panel-heading">
            <div><p class="eyebrow">Team</p><h2>Staff accounts</h2><p>Manage usernames, contact details, and profile pictures.</p></div>
            <a class="button primary" href="{{ route('users.create') }}">＋ Add user</a>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>User</th><th>Username</th><th>Email</th><th>Avatar status</th><th class="align-right">Action</th></tr></thead>
                <tbody>
                @forelse ($users as $user)
                    <tr>
                        <td>
                            <div class="identity">
                                <img class="avatar" src="{{ $user->avatar ? Storage::disk('public')->url($user->avatar) : asset('images/avatar-placeholder.svg') }}" alt="{{ $user->full_name }} profile picture">
                                <div><strong>{{ $user->full_name }}</strong><small>Staff account</small></div>
                            </div>
                        </td>
                        <td><span class="username">{{ '@'.$user->username }}</span></td>
                        <td>{{ $user->email ?: '—' }}</td>
                        <td><span class="status {{ $user->avatar ? 'ready' : '' }}"><i></i>{{ $user->avatar ? 'Prepared' : 'Placeholder' }}</span></td>
                        <td class="align-right"><a class="button ghost" href="{{ route('users.edit', $user) }}">Edit</a></td>
                    </tr>
                @empty
                    <tr><td colspan="5"><div class="empty-state"><strong>No user accounts yet</strong><span>Add the first account to get started.</span></div></td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        @if ($users->hasPages())
            <div class="pager">
                @if ($users->onFirstPage()) <span>← Previous</span> @else <a href="{{ $users->previousPageUrl() }}">← Previous</a> @endif
                <small>Page {{ $users->currentPage() }} of {{ $users->lastPage() }}</small>
                @if ($users->hasMorePages()) <a href="{{ $users->nextPageUrl() }}">Next →</a> @else <span>Next →</span> @endif
            </div>
        @endif
    </div>
@endsection
