<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') · Ramos POS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <a class="brand" href="{{ route('dashboard') }}" aria-label="Ramos POS home">
                <span class="brand-mark">R</span>
                <span><strong>Ramos</strong><small>Point of Sale</small></span>
            </a>

            <nav class="nav" aria-label="Main navigation">
                <a class="{{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                    <span aria-hidden="true">▦</span> Dashboard
                </a>
                <a class="{{ request()->routeIs('customers.*') ? 'active' : '' }}" href="{{ route('customers.index') }}">
                    <span aria-hidden="true">◎</span> Customers
                </a>
                <a class="{{ request()->routeIs('users.*') ? 'active' : '' }}" href="{{ route('users.index') }}">
                    <span aria-hidden="true">◇</span> User Accounts
                </a>
            </nav>

            <div class="sidebar-footer">
                <span class="status-dot"></span>
                <div><strong>System online</strong><small>Laravel POS</small></div>
            </div>
        </aside>

        <main class="main">
            <header class="topbar">
                <div>
                    <p class="eyebrow">Account management</p>
                    <h1>@yield('heading', 'Dashboard')</h1>
                </div>
                <div class="author-chip"><span>KR</span><div>Karl Ramos<small>Administrator</small></div></div>
            </header>

            <section class="content">
                @if (session('success'))
                    <div class="alert success" role="status">{{ session('success') }}</div>
                @endif

                @yield('content')
            </section>
        </main>
    </div>
</body>
</html>
