# Ramos POS — Customer and User Accounts

A Laravel 13 laboratory project by **Karl Ramos**. This submission extends a point-of-sale application with validated customer and user account management and display-ready avatar uploads.

## Features

- Customer listing, create, and edit pages
- Required customer name and RFC-valid email validation
- User account listing, create, and edit pages
- Required, unique usernames and required full names
- Forms preserve submitted values with Laravel `old()` and show field-level errors
- Avatar upload validation for JPG, PNG, and WebP files up to 2 MB
- Server-side avatar crop and resize to a consistent 320 × 320 JPEG using Intervention Image
- Safe writes through `Storage::disk('public')`; only the relative avatar path is saved in the database
- Prepared avatars on the account listing with a built-in placeholder fallback
- Responsive dashboard and account-management interface
- Seed data and a focused feature-test suite

## Requirements

- PHP 8.3 or newer with `fileinfo`, `gd`, `pdo`, and `pdo_sqlite`
- Composer 2

## Local setup

```bash
git clone <your-repository-url>
cd laravel-pos
composer install
cp .env.example .env
php artisan key:generate
touch database/database.sqlite
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000).

The default `.env.example` is configured for SQLite. If you prefer MySQL, update the `DB_*` values in `.env`, create the database, and then run `php artisan migrate --seed`.

## Demo data

Running the seeders creates two customers and two users. The sample users are:

| Username | Email | Password |
| --- | --- | --- |
| `admin` | `admin@example.com` | `password` |
| `cashier` | `cashier@example.com` | `password` |

Authentication is outside this activity's scope; these credentials are seeded to keep the records ready for a future login module.

## Run tests

```bash
php artisan test
```

The tests cover required and valid fields, unique usernames, old-input preservation, pre-filled edit forms, database updates, avatar type/size validation, public-disk storage, 320 × 320 processing, saved path behavior, and placeholder display.

## Avatar upload flow

1. `UpdateUserRequest` rejects non-images and files larger than 2 MB.
2. `AvatarService` decodes the validated upload with Intervention Image.
3. The image is center-cropped and resized to 320 × 320, then encoded as an 82-quality JPEG.
4. The processed bytes are written to `avatars/<uuid>.jpg` on the public disk.
5. Only that relative path is stored in `users.avatar`.
6. When an avatar is replaced, the previous processed file is removed.

For production hosting, point the web root to `public/`, configure the production database and `APP_URL`, run migrations, and run `php artisan storage:link` on the server.

## Main project structure

```text
app/
├── Http/Controllers/       # Page and update workflows
├── Http/Requests/          # Validation rules and messages
├── Models/                 # Customer and User models
└── Services/AvatarService.php
database/
├── migrations/             # Customer and avatar schema
└── seeders/                # Demonstration records
resources/views/
├── customers/
├── layouts/
└── users/
tests/Feature/              # Rubric-focused feature tests
```

## Submission checklist

- Commit the complete project, including `composer.lock`.
- Do not commit `.env`, `vendor/`, or uploaded files from `storage/app/public/avatars`.
- Add the deployed application URL to this README before final submission.
- Verify the hosted environment has a public storage link and the GD PHP extension enabled.
