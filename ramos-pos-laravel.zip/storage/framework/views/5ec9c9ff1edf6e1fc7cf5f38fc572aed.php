<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> · Ramos POS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <a class="brand" href="<?php echo e(route('dashboard')); ?>" aria-label="Ramos POS home">
                <span class="brand-mark">R</span>
                <span><strong>Ramos</strong><small>Point of Sale</small></span>
            </a>

            <nav class="nav" aria-label="Main navigation">
                <a class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>">
                    <span aria-hidden="true">▦</span> Dashboard
                </a>
                <a class="<?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>" href="<?php echo e(route('customers.index')); ?>">
                    <span aria-hidden="true">◎</span> Customers
                </a>
                <a class="<?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>" href="<?php echo e(route('users.index')); ?>">
                    <span aria-hidden="true">◇</span> User Accounts
                </a>
            </nav>

            <div class="sidebar-footer">
                <span class="status-dot"></span>
                <div><strong>System online</strong><small>Laravel POS</small></div>
            </div>
        </aside>

        <main class="main">
            <header class="topbar">
                <div>
                    <p class="eyebrow">Account management</p>
                    <h1><?php echo $__env->yieldContent('heading', 'Dashboard'); ?></h1>
                </div>
                <div class="author-chip"><span>KR</span><div>Karl Ramos<small>Administrator</small></div></div>
            </header>

            <section class="content">
                <?php if(session('success')): ?>
                    <div class="alert success" role="status"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </div>
</body>
</html>
<?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/layouts/app.blade.php ENDPATH**/ ?>