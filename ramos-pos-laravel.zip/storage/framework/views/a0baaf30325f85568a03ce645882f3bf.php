<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('heading', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-heading">
            <div><p class="eyebrow">Directory</p><h2>Customer records</h2><p>Keep contact information accurate and up to date.</p></div>
            <a class="button primary" href="<?php echo e(route('customers.create')); ?>">＋ Add customer</a>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>Customer</th><th>Phone</th><th>Address</th><th class="align-right">Action</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><div class="identity"><span class="initials"><?php echo e(str($customer->full_name)->substr(0, 1)->upper()); ?></span><div><strong><?php echo e($customer->full_name); ?></strong><small><?php echo e($customer->email); ?></small></div></div></td>
                        <td><?php echo e($customer->phone ?: '—'); ?></td>
                        <td><?php echo e($customer->address ?: '—'); ?></td>
                        <td class="align-right"><a class="button ghost" href="<?php echo e(route('customers.edit', $customer)); ?>">Edit</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4"><div class="empty-state"><strong>No customers yet</strong><span>Add the first customer to get started.</span></div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($customers->hasPages()): ?>
            <div class="pager">
                <?php if($customers->onFirstPage()): ?> <span>← Previous</span> <?php else: ?> <a href="<?php echo e($customers->previousPageUrl()); ?>">← Previous</a> <?php endif; ?>
                <small>Page <?php echo e($customers->currentPage()); ?> of <?php echo e($customers->lastPage()); ?></small>
                <?php if($customers->hasMorePages()): ?> <a href="<?php echo e($customers->nextPageUrl()); ?>">Next →</a> <?php else: ?> <span>Next →</span> <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/customers/index.blade.php ENDPATH**/ ?>