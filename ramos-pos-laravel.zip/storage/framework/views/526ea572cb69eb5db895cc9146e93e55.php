<?php $__env->startSection('title', 'Edit Customer'); ?>
<?php $__env->startSection('heading', 'Edit customer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-page">
        <div class="form-intro"><a href="<?php echo e(route('customers.index')); ?>">← Back to customers</a><h2>Update customer details</h2><p>Editing <?php echo e($customer->full_name); ?>.</p></div>
        <form class="panel form-panel" method="POST" action="<?php echo e(route('customers.update', $customer)); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('customers._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/customers/edit.blade.php ENDPATH**/ ?>