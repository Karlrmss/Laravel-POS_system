<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('heading', 'Edit user account'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-page wide">
        <div class="form-intro"><a href="<?php echo e(route('users.index')); ?>">← Back to user accounts</a><h2>Update account</h2><p>Editing <?php echo e($user->full_name); ?>.</p></div>
        <form class="panel form-panel" method="POST" action="<?php echo e(route('users.update', $user)); ?>" enctype="multipart/form-data" novalidate>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('users._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/users/edit.blade.php ENDPATH**/ ?>