<?php $__env->startSection('title', 'User Accounts'); ?>
<?php $__env->startSection('heading', 'User accounts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel">
        <div class="panel-heading">
            <div><p class="eyebrow">Team</p><h2>Staff accounts</h2><p>Manage usernames, contact details, and profile pictures.</p></div>
            <a class="button primary" href="<?php echo e(route('users.create')); ?>">＋ Add user</a>
        </div>

        <div class="table-wrap">
            <table>
                <thead><tr><th>User</th><th>Username</th><th>Email</th><th>Avatar status</th><th class="align-right">Action</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="identity">
                                <img class="avatar" src="<?php echo e($user->avatar ? Storage::disk('public')->url($user->avatar) : asset('images/avatar-placeholder.svg')); ?>" alt="<?php echo e($user->full_name); ?> profile picture">
                                <div><strong><?php echo e($user->full_name); ?></strong><small>Staff account</small></div>
                            </div>
                        </td>
                        <td><span class="username"><?php echo e('@'.$user->username); ?></span></td>
                        <td><?php echo e($user->email ?: '—'); ?></td>
                        <td><span class="status <?php echo e($user->avatar ? 'ready' : ''); ?>"><i></i><?php echo e($user->avatar ? 'Prepared' : 'Placeholder'); ?></span></td>
                        <td class="align-right"><a class="button ghost" href="<?php echo e(route('users.edit', $user)); ?>">Edit</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5"><div class="empty-state"><strong>No user accounts yet</strong><span>Add the first account to get started.</span></div></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($users->hasPages()): ?>
            <div class="pager">
                <?php if($users->onFirstPage()): ?> <span>← Previous</span> <?php else: ?> <a href="<?php echo e($users->previousPageUrl()); ?>">← Previous</a> <?php endif; ?>
                <small>Page <?php echo e($users->currentPage()); ?> of <?php echo e($users->lastPage()); ?></small>
                <?php if($users->hasMorePages()): ?> <a href="<?php echo e($users->nextPageUrl()); ?>">Next →</a> <?php else: ?> <span>Next →</span> <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/users/index.blade.php ENDPATH**/ ?>