<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" <?php echo e($attributes); ?>>
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
</svg>
<?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/vendor/laravel/framework/src/Illuminate/Foundation/resources/exceptions/renderer/components/icons/check.blade.php ENDPATH**/ ?>