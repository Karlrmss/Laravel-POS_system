<?php $__env->startSection('title', 'Create Customer'); ?>
<?php $__env->startSection('heading', 'Create customer'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-page">
        <div class="form-intro"><a href="<?php echo e(route('customers.index')); ?>">← Back to customers</a><h2>New customer details</h2><p>Fields marked with an asterisk are required.</p></div>
        <form class="panel form-panel" method="POST" action="<?php echo e(route('customers.store')); ?>" novalidate>
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('customers._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karlramos/Documents/Codex/2026-11-09/background-information-this-activity-replicates-tfa3/outputs/laravel-pos/resources/views/customers/create.blade.php ENDPATH**/ ?>