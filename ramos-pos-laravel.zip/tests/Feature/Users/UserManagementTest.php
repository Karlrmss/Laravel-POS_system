<?php

namespace Tests\Feature\Users;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Laravel\Facades\Image;
use Tests\TestCase;

class UserManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_creation_requires_unique_username_and_full_name(): void
    {
        User::factory()->create(['username' => 'cashier']);

        $this->post(route('users.store'), [
            'username' => 'cashier',
            'full_name' => '',
        ])->assertSessionHasErrors(['username', 'full_name']);
    }

    public function test_user_can_be_created_and_edited_with_prefilled_values(): void
    {
        $this->post(route('users.store'), [
            'username' => 'clerk_01',
            'full_name' => 'Jamie Cruz',
            'email' => 'jamie@example.com',
        ])->assertRedirect(route('users.index'));

        $user = User::where('username', 'clerk_01')->firstOrFail();

        $this->get(route('users.edit', $user))
            ->assertOk()
            ->assertSee('value="clerk_01"', false)
            ->assertSee('value="Jamie Cruz"', false);

        $this->put(route('users.update', $user), [
            'username' => 'clerk_01',
            'full_name' => 'Jamie S. Cruz',
            'email' => 'jamie@example.com',
        ])->assertRedirect(route('users.index'));

        $this->assertDatabaseHas('users', [
            'id' => $user->id,
            'full_name' => 'Jamie S. Cruz',
        ]);
    }

    public function test_avatar_must_be_an_image_no_larger_than_two_megabytes(): void
    {
        Storage::fake('public');
        $user = User::factory()->create();

        $this->put(route('users.update', $user), [
            'username' => $user->username,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'avatar' => UploadedFile::fake()->create('notes.txt', 10, 'text/plain'),
        ])->assertSessionHasErrors('avatar');

        $this->put(route('users.update', $user), [
            'username' => $user->username,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'avatar' => UploadedFile::fake()->image('large.jpg')->size(2049),
        ])->assertSessionHasErrors('avatar');
    }

    public function test_avatar_is_cropped_stored_on_public_disk_and_only_its_path_is_saved(): void
    {
        Storage::fake('public');
        $user = User::factory()->create();

        $this->put(route('users.update', $user), [
            'username' => $user->username,
            'full_name' => $user->full_name,
            'email' => $user->email,
            'avatar' => UploadedFile::fake()->image('portrait.png', 640, 480),
        ])->assertRedirect(route('users.index'));

        $avatarPath = $user->fresh()->avatar;

        $this->assertNotNull($avatarPath);
        $this->assertStringStartsWith('avatars/', $avatarPath);
        $this->assertStringEndsWith('.jpg', $avatarPath);
        Storage::disk('public')->assertExists($avatarPath);

        $image = Image::decode(Storage::disk('public')->get($avatarPath));
        $this->assertSame(320, $image->width());
        $this->assertSame(320, $image->height());

        $this->get(route('users.index'))
            ->assertOk()
            ->assertSee(Storage::disk('public')->url($avatarPath));
    }

    public function test_user_without_avatar_uses_placeholder(): void
    {
        User::factory()->create(['avatar' => null]);

        $this->get(route('users.index'))
            ->assertOk()
            ->assertSee(asset('images/avatar-placeholder.svg'));
    }
}
