<?php

namespace Tests\Feature\Customers;

use App\Models\Customer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_customer_pages_are_available(): void
    {
        $customer = Customer::create([
            'full_name' => 'Ana Santos',
            'email' => 'ana@example.com',
        ]);

        $this->get(route('customers.index'))->assertOk()->assertSee('Ana Santos');
        $this->get(route('customers.create'))->assertOk()->assertSee('Create customer');
        $this->get(route('customers.edit', $customer))->assertOk()->assertSee('value="Ana Santos"', false);
    }

    public function test_customer_creation_requires_a_name_and_valid_email_and_keeps_old_input(): void
    {
        $response = $this->from(route('customers.create'))->post(route('customers.store'), [
            'full_name' => 'Remember Me',
            'email' => 'not-an-email',
        ]);

        $response->assertRedirect(route('customers.create'))
            ->assertSessionHasErrors(['email'])
            ->assertSessionHasInput('full_name', 'Remember Me');

        $this->post(route('customers.store'), ['email' => 'valid@example.com'])
            ->assertSessionHasErrors(['full_name']);
    }

    public function test_customer_can_be_created_and_updated(): void
    {
        $this->post(route('customers.store'), [
            'full_name' => 'Maria Dela Cruz',
            'email' => 'maria@example.com',
            'phone' => '09171234567',
            'address' => 'Manila',
        ])->assertRedirect(route('customers.index'));

        $customer = Customer::where('email', 'maria@example.com')->firstOrFail();

        $this->put(route('customers.update', $customer), [
            'full_name' => 'Maria Cruz',
            'email' => 'maria@example.com',
            'phone' => '09171234567',
            'address' => 'Quezon City',
        ])->assertRedirect(route('customers.index'));

        $this->assertDatabaseHas('customers', [
            'id' => $customer->id,
            'full_name' => 'Maria Cruz',
            'address' => 'Quezon City',
        ]);
    }
}
