<?php

namespace Database\Seeders;

use App\Models\Customer;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Customer::query()->insert([
            [
                'full_name' => 'Ana Santos',
                'email' => 'ana.santos@example.com',
                'phone' => '0917 555 0142',
                'address' => 'Quezon City, Metro Manila',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'full_name' => 'Miguel Reyes',
                'email' => 'miguel.reyes@example.com',
                'phone' => '0918 555 0198',
                'address' => 'Makati City, Metro Manila',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
