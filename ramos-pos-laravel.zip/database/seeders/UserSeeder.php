<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::query()->create([
            'username' => 'admin',
            'full_name' => 'Karl Ramos',
            'email' => 'admin@example.com',
            'password' => 'password',
        ]);

        User::query()->create([
            'username' => 'cashier',
            'full_name' => 'Jamie Cruz',
            'email' => 'cashier@example.com',
            'password' => 'password',
        ]);
    }
}
