<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Intervention\Image\Laravel\Facades\Image;

final class AvatarService
{
    public function store(UploadedFile $upload): string
    {
        $path = 'avatars/'.Str::uuid().'.jpg';

        $thumbnail = Image::decode($upload)
            ->cover(320, 320)
            ->encodeUsingFileExtension('jpg', quality: 82);

        Storage::disk('public')->put($path, (string) $thumbnail);

        return $path;
    }
}
