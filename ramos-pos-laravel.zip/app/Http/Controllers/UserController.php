<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreUserRequest;
use App\Http\Requests\UpdateUserRequest;
use App\Models\User;
use App\Services\AvatarService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class UserController extends Controller
{
    public function __construct(private readonly AvatarService $avatars) {}

    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        return view('users.index', [
            'users' => User::query()->latest()->paginate(10),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view('users.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserRequest $request): RedirectResponse
    {
        User::create($request->validated());

        return to_route('users.index')->with('success', 'User account created successfully.');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user): View
    {
        return view('users.edit', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserRequest $request, User $user): RedirectResponse
    {
        $data = Arr::except($request->validated(), ['avatar']);

        if (blank($data['password'] ?? null)) {
            unset($data['password']);
        }

        $oldAvatar = $user->avatar;

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $this->avatars->store($request->file('avatar'));
        }

        $user->update($data);

        if (isset($data['avatar']) && $oldAvatar) {
            Storage::disk('public')->delete($oldAvatar);
        }

        return to_route('users.index')->with('success', 'User account updated successfully.');
    }
}
