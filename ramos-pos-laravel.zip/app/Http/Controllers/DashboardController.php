<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\User;
use Illuminate\View\View;

final class DashboardController extends Controller
{
    public function __invoke(): View
    {
        return view('dashboard', [
            'customerCount' => Customer::count(),
            'userCount' => User::count(),
        ]);
    }
}
